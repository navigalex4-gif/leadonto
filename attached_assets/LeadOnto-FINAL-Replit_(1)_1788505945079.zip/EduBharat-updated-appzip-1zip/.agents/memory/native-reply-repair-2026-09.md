# Native-reply repair hardening (2026-09-03)

Diagnosed from a real user PDF (2026-09-03) + activity CSV. Fixes in
`artifacts/edubharat/src/pages/english-guru.tsx`:

- `isNativeLanguageTurn` now needs >=4 native chars AND >=50% letter ratio —
  "Hello माया ma'am" small talk no longer forces a mandatory-native turn.
- `cleanSpokenReply` is repair-first: collapse fragmented spacing, salvage
  Latin (>=6 Latin words), static `NATIVE_RETRY_FALLBACKS` line is LAST
  RESORT only. Turn-level anti-repeat (canned line in last 4 AI turns →
  variedFallback) prevents the canned-line loop users complained about.
- CRITICAL Unicode lesson: Indic vowel signs (matras ि ी ु) are `\p{M}`
  (combining marks), NOT `\p{L}`. Every `[^\p{L}\p{N}\s]` normalizer in this
  file stripped them, silently garbling Devanagari/Tamil/Telugu and making
  `looksLikeGenericNativeAcknowledgement` a dead detector for Indic phrases
  (phrase list contains matras; normalized input did not). All 7 sites now
  use `[^\p{L}\p{M}\p{N}\s]`.
- `collapseFragmentedNativeScript` merges a token only when a neighbor is a
  short (<=2 script chars) fragment — intact >=3-char words keep their
  spaces (old regex glued whole sentences into one non-word). Sentence
  punctuation (। ॥ ۔) is excluded from boundary tests because danda sits
  INSIDE the Devanagari Unicode block.
- Translation failure path: retry x2, `translationServiceFailed` flag +
  `track("translation_failed")`, honest English hiccup message; generic-ack
  and malformedTranslation checks skip when the flag is set.
- `login.tsx`: fail-CLOSED Google button (config-loaded && googleConfigured),
  Email OTP is now the primary CTA. CSV evidence: 20/23 google signup
  starts -> 0 accounts (OAuth dies off-site, fix redirect URI in Google
  Cloud Console); email OTP converted 3/3.
- `routes/auth.ts`: `googleStrategyRegistered` flag; `/auth/google`
  redirects to `/login?error=google_unavailable` when unregistered.
- `buy-credits.tsx` now fires `payment_submitted/approved/rejected`
  (events existed in `lib/analytics.ts` but were never fired).
- `export-conversation.ts`: invisible jsPDF text layer so exported PDFs are
  text-searchable (source PDF evidence had an empty text layer).

Test harness: `/tmp/nl-test.ts` (esbuild-bundled, react/lucide stubbed) —
14 assertions T1–T13 covering native-turn gating, fragmentation repair,
matra preservation, static-line detector, and last-resort behavior.

## Cross-service audit (2026-09-03 late)
- interview-ace.tsx + communication-check.tsx had the same `[^\p{L}\p{N}\s]`
  regex, but only inside question-dedup normalizers where BOTH sides are
  normalized identically, and both flows are English-only today — so the
  matra bug could not bite. Fixed defensively anyway (`\p{M}` added) so
  future native-language questions can't reintroduce it.
- lib/use-edge-tts.ts already used `\p{L}\p{M}` correctly (line ~350).
- lib/english-tools.ts stripMarkdownForSpeech only strips markdown symbols —
  unaffected.
- tools-pro.tsx passes nativeLanguage correctly and speak() defaults to the
  user's UI language; the two hardcoded "English" speak calls are deliberate
  (pronunciation practice of English words).
- resume-intelligence / rozgar-samachar / learning-journey / b2b / admin
  pages have no native-script processing — nothing to fix.

## Full-repo audit (2026-09-04) — every service + content
- Two MORE matra sites found in english-guru.tsx n-gram dedup comparer
  (collapseRepeatedSpeech, lines 1059/1060) — fixed to \p{M}.
- API server: native-language-policy.ts + translation.ts + stt.ts use
  script-block regexes (no letter-class stripping) — already correct, matra
  bug could not occur server-side.
- stt.ts isLikelyCorruptedIndicTranscript mirrors the client fragmentation
  guard — already handles dropped Devanagari vowel signs via latest_long.
- Analytics: all 22 canonical FunnelEvent types are fired (otp_expired via
  ternary in login.tsx). No defined-but-dead events remain.
- Routes: all 43 wouter routes resolve; zero dead internal links.
- Content: only intentional "coming soon" (unseeded journey levels) + one
  code comment — both legitimate, not placeholder debt.
