# Interview Ace — Report Engine (reference implementation)

A standalone rebuild of the interview feedback report, built to fix two things
found in the Sales Manager report dated 18/8/2026:

1. **The bug**: selecting a role never updated Experience Level away from its
   "Fresher" default, so an interview with a candidate who stated 20 years of
   experience got scored — and then judged — as if they were a fresher.
2. **The report itself**: several structural gaps made it feel unreliable
   rather than genuine — see "What changed and why" below.

## Run it on Replit

1. Create a new Replit → **Import from GitHub** (if you push this folder to
   a repo) or **Upload folder** and drop these files in directly.
2. Replit detects Python from `requirements.txt` and `.replit`. Hit **Run**.
3. Open the webview. You'll land on the setup page.
4. Click **"Load real sample"** in the top nav to see the fix applied to the
   actual transcript from the report you sent — the Setup Issue banner at the
   top of that report is the tool catching the exact mismatch that shipped
   in the original.

No API key is required to run it. Without one, the summary paragraph is
written by a deterministic template instead of Claude — everything else
(scoring, flags, evidence, layout) works identically either way.

### Turning on AI-written narrative summaries (optional)
In your Repl, open **Tools → Secrets** and add:
```
ANTHROPIC_API_KEY = sk-ant-...
```
Get a key at https://console.anthropic.com. `llm.py` calls `claude-sonnet-5`
by default — swap the `MODEL` constant for a cheaper model (e.g.
`claude-haiku-4-5-20251001`) if you're generating reports at volume. Check
https://docs.claude.com for the current recommended model string before
deploying, since these change over time.

## Files

| File | Purpose |
|---|---|
| `rubrics.py` | Role configs: competencies, weights, question bank, and — this is the bug fix — a `default_experience_level` per role plus the list of levels that role is even allowed to offer. |
| `evidence.py` | Small explainable heuristics (word count, sentence-completeness, STAR keyword coverage) that scoring is built from, instead of an LLM's impression. |
| `report_engine.py` | `check_setup_integrity()`, `check_competency_coverage()`, and `build_report()` — the core logic. |
| `llm.py` | Optional, strictly-grounded narrative writer with a template fallback. |
| `app.py` | Flask routes. |
| `templates/`, `static/` | Setup form (with the live role→level sync) and the report layout. |
| `sample_data/sales_manager_transcript.json` | Your real transcript, restructured into this app's schema. |

## What changed and why

**Experience level now has a real default per role, and the level select
only offers levels that make sense for that role.** `rubrics.py` sets
`"default_experience_level": "experienced"` for Sales Manager — the JS in
`static/app.js` (`syncLevelToRole`) fires on every role change and rebuilds
the Experience Level `<select>` from that role's `experience_levels` list, so
"Fresher" isn't even an option for a manager-level interview. This is the
direct fix for the reported bug.

**A setup-integrity check runs before a verdict is finalized.**
`check_setup_integrity()` reads the candidate's stated experience out of
their introduction and compares it against whatever Experience Level was
selected. On a mismatch, it raises a flag ("read this as a setup issue, not
a candidate credibility issue") instead of letting the report assert that
the candidate misrepresented themselves. Even with the dropdown fixed, an
admin can still pick the wrong level by hand — this is the backstop.

**A thinly-evidenced, heavily-weighted score gets flagged, not hidden.**
The original report weighted Functional Knowledge at 25% but only 3 of 16
questions were domain-specific. `check_competency_coverage()` now checks
this automatically: any competency worth 12%+ of the total with fewer than
two questions behind it gets a visible coverage note.

**There was no dedicated Leadership competency for a *manager* role.** It
was folded into "Collaboration" at best. The Sales Manager rubric now scores
Leadership & People Management on its own (15%), with two new
scenario questions (`Q17`, `Q18` in `rubrics.py`) covering a difficult
performance conversation and motivating a team through a slow quarter —
neither was asked in the original interview.

**English fluency and communication effectiveness are scored separately.**
The original blended them into one "Communication Skills" line, which risks
penalizing a non-native English speaker twice for the same root cause. They're
now two competencies, each citing its own evidence.

**Every score is evidence-linked.** Each competency shows the exact
question(s) and excerpted answer(s) it was scored from — the "View evidence"
disclosure in `report.html` — plus a "low signal" tag on answers too short
to score with real confidence (the original scored a six-word answer to Q9
with the same apparent confidence as a full answer).

**The weighted math is shown, not just asserted.** "How this score was
calculated" breaks weight × score = contribution down per competency.

**The verdict now carries a confidence level, and low-confidence reports say
so.** If a setup flag or thin coverage is present, "Recommendation
confidence" drops to Medium/Low and the report explicitly says not to use it
for a decision as-is — closer to how regulated hiring tools are expected to
behave (human review before an adverse automated decision), and just
generally more honest about what the data actually supports.

**The "Best-Fit Role: Data Entry Specialist" suggestion was dropped.**
An AI tool asserting an alternative career path for someone off a single
flawed 10-minute interview is a real reputational and fairness risk,
especially once you know the interview itself was scored under the wrong
setup. Nothing in this codebase generates that kind of claim.

**A limitations note is included whenever fluency is a likely confound.**
The report's disclaimer explicitly asks the human reviewer to consider
whether weak English expression is masking real domain knowledge, rather
than presenting the domain-knowledge score as a clean, standalone fact.

## Extending it

- **Add a role**: add an entry to `ROLES` in `rubrics.py` with competencies
  (weights summing to 100) and a `question_bank`. The setup page and scoring
  pick it up automatically — no other file needs to change.
- **Wire in your real interview pipeline**: instead of the guided form, POST
  to `/generate` with `mode=json` and a `transcript_json` field matching the
  schema in `sample_data/sales_manager_transcript.json` (list of `id`,
  `competency`, `type`, `prompt`, `answer`).
- **Persistence**: reports currently live in an in-memory dict in `app.py`
  (`REPORTS`) and are lost on restart. For anything beyond a demo, swap that
  for Replit DB, SQLite, or Postgres.
- **PDF export**: the report page is print-styled (`@media print` in
  `style.css`), so "Print / save as PDF" in the browser works today. For a
  server-generated PDF instead, add `weasyprint` or `xhtml2pdf` — left out
  here since they need system-level dependencies that can be brittle on
  Replit's default image.
- **Compliance**: if candidates in the US or EU are in scope, look into NYC
  Local Law 144, Colorado SB 24-205, Illinois HB 3773, and the EU AI Act's
  rules for automated employment decision tools — most require notifying
  candidates an automated tool was used, periodic independent bias audits,
  and a human in the loop before an adverse decision. This isn't legal
  advice; talk to a lawyer before relying on this tool for real hiring
  decisions in those jurisdictions.
