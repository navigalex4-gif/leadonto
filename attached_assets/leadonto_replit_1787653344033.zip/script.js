window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}
gtag('js',new Date());
function track(name,params){try{gtag('event',name,params||{});}catch(e){}
  if(window.console&&console.debug)console.debug('[track]',name,params||{});}

/* ---------- demo picker state ---------- */
var LP={lang:'Hindi',goal:'a job interview'};
function wire(id,key,ev){
  var box=document.getElementById(id); if(!box)return;
  box.addEventListener('click',function(e){
    var b=e.target.closest('.opt'); if(!b)return;
    box.querySelectorAll('.opt').forEach(function(o){o.setAttribute('aria-pressed','false');});
    b.setAttribute('aria-pressed','true');
    LP[key]=b.getAttribute('data-v');
    render(); track(ev,{value:LP[key]});
  });
}
function render(){
  var o=document.getElementById('pickOut'); if(!o)return;
  var help = LP.lang==='English only'
    ? 'kept fully in <em>English</em>'
    : 'with help in <em>'+LP.lang+'</em> whenever you\'re stuck';
  o.innerHTML='🎯 Your session: practising <em>'+LP.goal+'</em>, '+help+'.';
  var btn=document.getElementById('startBtn');
  if(btn){btn.href='/english-guru?src=lp&lang='+encodeURIComponent(LP.lang)+'&goal='+encodeURIComponent(LP.goal);}
}
wire('langOpts','lang','demo_language_select');
wire('goalOpts','goal','demo_goal_select');
render();

/* ---------- billing toggle ---------- */
function setBilling(mode){
  var y = mode==='y';
  document.getElementById('bMonthly').setAttribute('aria-pressed', y?'false':'true');
  document.getElementById('bYearly').setAttribute('aria-pressed', y?'true':'false');
  document.querySelectorAll('.amt').forEach(function(el){
    el.textContent = y ? el.getAttribute('data-y') : el.getAttribute('data-m');
  });
  document.querySelectorAll('.per').forEach(function(el){ el.textContent = y?'/year':'/month'; });
  document.querySelectorAll('.billnote').forEach(function(el){
    el.textContent = y ? 'Billed yearly · works out cheaper per month' : 'Billed monthly · cancel anytime';
  });
  track('pricing_toggle',{period: y?'yearly':'monthly'});
}

/* ---------- sticky bar after hero ---------- */
(function(){
  var bar=document.getElementById('sticky'), hero=document.getElementById('start');
  if(!bar||!hero)return;
  var fired=false;
  window.addEventListener('scroll',function(){
    var show = window.scrollY > 520;
    bar.classList.toggle('show', show);
    if(show&&!fired){fired=true;track('sticky_shown');}
  },{passive:true});
})();

/* ---------- animate score bars + pricing view event ---------- */
(function(){
  if(!('IntersectionObserver' in window)){
    document.querySelectorAll('.bar-f').forEach(function(b){b.style.width=b.getAttribute('data-w')+'%';});
    return;
  }
  var io=new IntersectionObserver(function(es){
    es.forEach(function(e){
      if(!e.isIntersecting)return;
      if(e.target.id==='scorecard'){
        e.target.querySelectorAll('.bar-f').forEach(function(b){b.style.width=b.getAttribute('data-w')+'%';});
      }
      if(e.target.id==='pricing'){track('pricing_view');}
      io.unobserve(e.target);
    });
  },{threshold:.25});
  ['scorecard','pricing'].forEach(function(id){
    var el=document.getElementById(id); if(el)io.observe(el);
  });
})();

/* ---------- scroll depth ---------- */
(function(){
  var marks=[25,50,75,100],hit={};
  window.addEventListener('scroll',function(){
    var h=document.documentElement,
        p=Math.round((h.scrollTop)/(h.scrollHeight-h.clientHeight)*100);
    marks.forEach(function(m){ if(p>=m&&!hit[m]){hit[m]=1;track('scroll_depth',{percent:m});} });
  },{passive:true});
})();

{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[
{"@type":"Question","name":"Is it really free? Do I need to give my card?","acceptedAnswer":{"@type":"Answer","text":"Your first 15 minutes are free with no signup and no card. Create a free account for 20 more credits (about 4 hours). You only enter payment details if you decide to subscribe."}},
{"@type":"Question","name":"My English is very weak. Will I be able to use this?","acceptedAnswer":{"@type":"Answer","text":"Yes. You can speak entirely in Hindi, Tamil, Telugu, Bengali and 9 other Indian languages, and your AI teacher will help you say it in English one sentence at a time."}},
{"@type":"Question","name":"How is this different from a free AI chatbot?","acceptedAnswer":{"@type":"Answer","text":"It is spoken rather than typed, it switches to your mother tongue at the moment you get stuck, and it tracks a Fluency Score across sessions so you can see measurable improvement."}},
{"@type":"Question","name":"Will it work on my phone and my data pack?","acceptedAnswer":{"@type":"Answer","text":"Yes. It runs in your phone browser with nothing to install, and includes an audio-light mode built for patchy 3G connections."}},
{"@type":"Question","name":"How do credits work?","acceptedAnswer":{"@type":"Answer","text":"One credit covers 12 minutes of live conversation (5 credits per hour). Starter includes 60 credits per month. Fluency Pro and Career Pro include unlimited practice."}},
{"@type":"Question","name":"Can I cancel? What if it doesn't work for me?","acceptedAnswer":{"@type":"Answer","text":"Cancel in one tap from your account. If you are within 7 days of subscribing, reply to any email from us for a full refund."}}
]}
